import { Component } from '@angular/core';

@Component({
  selector: 'app-corporates-booking',
  templateUrl: './corporates-booking.component.html',
  styleUrls: ['./corporates-booking.component.css']
})
export class CorporatesBookingComponent {

}
