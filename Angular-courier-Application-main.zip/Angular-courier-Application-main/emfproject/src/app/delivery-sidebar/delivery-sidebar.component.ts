import { Component } from '@angular/core';

@Component({
  selector: 'app-delivery-sidebar',
  templateUrl: './delivery-sidebar.component.html',
  styleUrls: ['./delivery-sidebar.component.css']
})
export class DeliverySidebarComponent {

}
