import { Executive } from './executive';

describe('Executive', () => {
  it('should create an instance', () => {
    expect(new Executive()).toBeTruthy();
  });
});
