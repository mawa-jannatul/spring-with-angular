export class Deliveryman {
    
    // heroId?: number;
    // heroName?: string;
    // heroCell?: string;
    // heroEmail?: string;
    // heroPassword?: string;
    // heroAddress?: string;
    // empId?: string;
    // heroCity?: string;
   
}
