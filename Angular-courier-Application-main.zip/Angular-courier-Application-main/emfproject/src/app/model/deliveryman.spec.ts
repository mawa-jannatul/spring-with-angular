import { Deliveryman } from './deliveryman';

describe('Deliveryman', () => {
  it('should create an instance', () => {
    expect(new Deliveryman()).toBeTruthy();
  });
});
