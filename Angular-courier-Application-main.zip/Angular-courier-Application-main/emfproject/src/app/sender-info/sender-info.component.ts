import { Component } from '@angular/core';

@Component({
  selector: 'app-sender-info',
  templateUrl: './sender-info.component.html',
  styleUrls: ['./sender-info.component.css']
})
export class SenderInfoComponent {

}
