import { Component } from '@angular/core';

@Component({
  selector: 'app-corporates',
  templateUrl: './corporates.component.html',
  styleUrls: ['./corporates.component.css']
})
export class CorporatesComponent {

}
